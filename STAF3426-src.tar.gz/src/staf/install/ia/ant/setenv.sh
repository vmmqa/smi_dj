#!
export PATH=/cygdrive/c/build/rel/win32/staf/retail/bin:/cygdrive/c/build/rel/win32/staf/retail/lib:/cygdrive/c/apache-ant-1.6.2/bin:/cygdrive/c/perl583/bin:$PATH
export CLASSPATH=.\;c:\\build\\rel\\win32\\staf\\retail\\lib\\JSTAF.jar\;c:\\build\\rel\\win32\\staf\\retail\\samples\\demo\\STAFDemo.jar\;c:\\build\\rel\\win32\\staf\\retail\\lib\\STAXMon.jar\;c:\\staf\\services\;c:\\apache-ant-1.6.2\\lib\\ant.jar\;c:\\build\\rel\\win32\\staf\\retail\\lib\\STAFAnt.jar
