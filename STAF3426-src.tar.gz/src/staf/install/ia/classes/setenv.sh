#!
export CLASSPATH=C:/IA2015/IAClasses.zip\;$CLASSPATH
