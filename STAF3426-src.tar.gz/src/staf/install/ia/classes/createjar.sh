c:/ibmjava50/bin/javac *.java
c:/ibmjava50/bin/jar cf STAFCustomCode.jar *.class
